<?php
$koneksi = mysqli_connect("localhost","root","","rizky_crud");
if (mysqli_connect_error()){
    echo "Gagal menyambung ke database" . mysqli_connect_error();
}
?>